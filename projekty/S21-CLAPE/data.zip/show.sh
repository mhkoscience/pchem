show -I$'\t'%irrrrr= $1 
