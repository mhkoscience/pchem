#!/bin/bash
if [ $# -lt 2 ]; then
  cat <<EOF
*** Skript pro studentskou ulohu "Clapeyronova rovnice" ***
Krok 3: priprava podlouhleho krystalu Na576Cl576, roztaveni poloviny a simulace
Syntax:
  vrstva.sh T P
kde parametry jsou
  T = teplota v K
  P = tlak v MPa
Priklad (zadano jako job, paralelne 4 procesory)
  jsub -n vT1300P0 -p 4 vrstva.sh 1300 0
EOF
  exit 1
fi

export LC_ALL=C

T=$1
P=$2

############ simulace vrstvy ###########

CR=crT${T}P${P}
SLAB=slabT${T}P${P}

if [ -e $CR.loc ] ; then
  echo "simulace $CR.loc jeste bezi"
  exit
fi

if [ ! -e $CR.sta ] ; then
  echo "neexistuje soubor $CR.sta, nutno dokoncit krok 1"
  exit
fi

V=`staprt -nV -ka $CR`

naclcryst 8 0 0 -olong%d -n1152 -m1152 -x2.25

rm long[012].*

cat > $SLAB.def <<EOF
n=576
N[0]=n N[1]=n         ! pocet Na+ a Cl-

rho=1900              ! referencni hustota [kg/m3]

cutoff=9              ! elst cutoff (pro~Ewaldovu~sumaci) [AA]
LJcutoff=cutoff       ! Lennard-Jones cutoff [AA]
el.epsk=2 el.epsr=0.4 ! presnost vypoctu elst. sil [K/AA]
el.diff=0.3           ! omezi urcita varovani o presnosti
noint=25 h=0.1/noint  ! pocet kroku/cyklus a delka kroku [ps]
dt.plb=1              ! jak casto se bude zapisovat "playback" [ps]
dt.prt=1              ! jak casto se bude zapisovat radek do prt-souboru

thermostat="Berendsen"! typ termostatu
T=$T              ! teplota [K]
tau.T=0.5             ! casova konstanta termostatu [ps]

P=${P}e6            ! tlak [Pa]
bulkmodulus=3e9+P     ! odhad modulu pruznosti (pro barostat, kapalina)

x=cbrt($V)            ! velikost boxu z kroku 1
L[0]=x                ! velikost boxu ve smeru x
L[1]=x                ! velikost boxu ve smeru y
L[2]=x*2.6            ! velikost boxu ve smeru z (2.25x + trochu pro taveni)
rho=0                 ! box nebude prepocitan podle hustoty, ale L[*] jsou presne
P=${P}e6              ! tlak [Pa]
;
EOF

cat > $SLAB.get <<EOF
! prvni krok: NVT nacteni a dorovnani velikosti boxu + taveni
init="plb"            ! bude se cist long3.plb
load.tr="yz"         ! transformace, aby delsi osa byla z
no=300
rescale="XYZCM"       ! velikost boxu se bude menit ve vsech smerech podle L[*]
tau.P=0               ! vypnuti barostatu
tau.rho=30            ! rychlost zmeny boxu (hustoty)
! zatim NVT: nastaveni boxu podle Lx,Ly,Lz

! roztaveni poloviny boxu
T=$T
slab.T=T+300          ! teplota v prostredni polovine boxu = T+300
slab.Tz0=0.25         ! definuje rozsah z pro jinou teplotu (v L[2])
slab.Tz1=0.75         ! definuje rozsah z pro jinou teplotu (v L[2])
T=T-300               ! teplota krystalu=T-300, nutno vratit
;
slab.T=-1             ! vypne termostat v polovine boxu
T=$T                  ! nastavi puvodni teplotu
init="append"
no=1000       ! jeden cyklus je 100 ps, cca 5 minut
tau.rho=0     ! rizeni objemu prevezme barostat
rescale="ZCM" ! barostat bude menit jen z
tau.P=3       ! konstanta barostatu [ps]
tau.T=1       ! konstanta termostatu [ps]
;;;;; ;;;;;   ! nekolik stejnych cyklu po 100 ps (po kazdem ; se uzavre slabT1300P0.cp)
EOF

cookewslcP1 nacl $SLAB long3.plb
