#!/bin/bash
if [ $# -lt 2 ]; then
  cat <<EOF
*** Skript pro studentskou ulohu "Clapeyronova rovnice" ***
Krok 2: roztaveni krystalu z kroku 1 a NPT simulace
Syntax:
  tavenina T P
kde parametry jsou
  T = teplota v K
  P = tlak v MPa
Priklad (zadano jako job, paralelne 4 procesory)
  jsub -n tT1300P0 -p 4 tavenina.sh 1300 0
EOF
  exit 1
fi

export LC_ALL=C

T=$1
P=$2

############ simulace taveniny ###########

MELT=meltT${T}P${P}

cp $CR.cfg $MELT.cfg

cat > $MELT.def <<EOF
n=256                 ! pomocna promenna
N[0]=n N[1]=n         ! pocet Na+ a Cl-

rho=1500              ! referencni hustota [kg/m3]

cutoff=9              ! elst cutoff (pro~Ewaldovu~sumaci)[AA]
LJcutoff=cutoff       ! Lennard-Jones cutoff [AA]
el.epsk=2 el.epsr=0.4 ! presnost vypoctu elst. sil [K/AA]
el.diff=0.3           ! omezi urcita varovani o presnosti
noint=25 h=0.1/noint  ! pocet kroku/cyklus a delka kroku [ps]
no=100                ! pocet cyklu
dt.plb=1              ! jak casto se bude zapisovat "playback" [ps]
dt.prt=1              ! jak casto se bude zapisovat radek do prt-souboru

thermostat="Berendsen"! typ termostatu
T=$T              ! teplota [K]
tau.T=0.5             ! casova konstanta termostatu [ps]

P=${P}*1e6            ! tlak [Pa]
bulkmodulus=3e9+P     ! odhad modulu pruznosti (pro barostat, kapalina)
tau.P=2               ! konstanta barostatu [ps]
;
EOF

cat >$MELT.get <<EOF
init="crystal"! pocatecni konfigurace je krystal s nepravidelne umistenymi atomy
no=20         ! kratce
tau.T=0.1     ! chlazeni
tau.P=100     ! velka konstanta barostatu, aby se prilis nezmenil objem
;
no=80         ! delsi
tau.T=0.3     ! chlazeni
tau.P=5       ! velka konstanta barostatu, aby se prilis nezmenil objem
;
init="append"
no=2000       ! dost dlouhe michani
tau.T=0.5
tau.P=2
;
init="append" ! pokracovat, ale veliciny merit po rozmichani
no=8000       ! pro kapalinu delsi produktivni beh
;
EOF

echo "****** SPOUSTIM KROK 2 -- VYPOCET TAVENINY ******"

cookewslcP1 nacl $MELT
