#!/bin/bash
if [ $# -lt 2 ]; then
  cat <<EOF
*** Skript pro studentskou ulohu "Clapeyronova rovnice" ***
Krok 1 + Krok 3  jedné simulaci
Syntax:
  krystal+vrstva.sh T P
kde parametry jsou
  T = teplota v K
  P = tlak v MPa
Priklad (zadano jako job, paralelne 4 procesory)
  jsub -n crT1300P0 -p 4 krystal+vrstva.sh 1300 0
EOF
  exit 1
fi

krystal.sh $1 $2
vrstva.sh $1 $2
