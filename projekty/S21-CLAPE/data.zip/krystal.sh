#!/bin/bash
if [ $# -lt 2 ]; then
  cat <<EOF
*** Skript pro studentskou ulohu "Clapeyronova rovnice" ***
Krok 1: priprava krystalu Na256Cl256 v periodickych okrajovych podminkach
        a NPT simulace
Syntax:
  krystal.sh T P
kde parametry jsou
  T = teplota v K
  P = tlak v MPa
Priklad (zadano jako job, paralelne 4 procesory)
  jsub -n crT1300P0 -p 4 krystal.sh 1300 0
EOF
  exit 1
fi

export LC_ALL=C

T=$1
P=$2

############ simulace krystalu ###########

# vyrobi krystal Na256Cl256
naclcryst 8 0 0 -n512 -x1

CR=crT${T}P${P}

cat > $CR.def <<EOF
n=256                 ! pomocna promenna
N[0]=n N[1]=n         ! pocet Na+ a Cl-

rho=1900              ! referencni hustota [kg/m3]

cutoff=9              ! elst cutoff (pro~Ewaldovu~sumaci) [AA]
LJcutoff=cutoff       ! Lennard-Jones cutoff [AA]
el.epsk=2 el.epsr=0.4 ! presnost vypoctu elst. sil [K/AA]
el.diff=0.3           ! omezi urcita varovani o presnosti
noint=25 h=0.1/noint  ! pocet kroku/cyklus a delka kroku [ps]
dt.plb=1              ! jak casto se bude zapisovat "playback" [ps]
dt.prt=1              ! jak casto se bude zapisovat radek do prt-souboru

thermostat="Berendsen"! typ termostatu
T=$T              ! teplota [K]
tau.T=0.5             ! casova konstanta termostatu [ps]

P=${P}e6            ! tlak [Pa]
bulkmodulus=(1e13+${P}e9)/(T+300) ! odhad modulu pruznosti (pro barostat)
tau.P=2               ! konstanta barostatu [ps]; pro kapalinu lze mene
;
EOF

cat > $CR.get <<EOF
init="plb"             ! nacte nacl-0000.plb
no=1000                ! dost dlouhe michani
;
init="append"
no=4000 tau.T=0.5 tau.P=2 ! produktivni beh
;
EOF

echo "****** SPOUSTIM KROK 1 -- VYPOCET KRYCHLOVEHO KRYSTALU Na256Cl256 ******"

cookewslcP1 nacl $CR nacl-0000.plb
